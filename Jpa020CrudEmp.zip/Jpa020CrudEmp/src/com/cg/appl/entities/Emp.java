package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity(name = "employee")
@Table(name = "EMP")
@NamedQueries({ @NamedQuery(name = "qryEmpsOnSal" , query = "select e from employee e where empSal between :from and :to"),
	@NamedQuery(name = "qryAllEmps" , query = "select e from employee e"),
	@NamedQuery(name = "qryEmpsComm", query = "select e from employee e where comm is null")
})

@SequenceGenerator(name = "emp_generate", sequenceName = "EMP_SEQ" , allocationSize=1, initialValue=1)
public class Emp implements Serializable {

	private static final long serialVersionUID = 1L;
	private int empNo;
	private String empNm;
	private Float comm;
	private transient Float totalSalary;
	private float empSal;

	
	@Id
	@GeneratedValue(generator="emp_generate", strategy = GenerationType.SEQUENCE)
	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	@Column(name = "ENAME")
	public String getEmpNm() {
		return empNm;
	}

	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}

	@Column(name = "SAL")
	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	@Column(name = "COMM")  				//Capital coz its table name
	public Float getComm() {
		return comm;
	}

	public void setComm(Float comm) {
		this.comm = comm;
	}

	//@Column(name = "SAL + COMM")
	@Transient
	public Float getTotalSalary() {
		return getEmpSal() + (getComm() == null ? 0:getComm());
	}

	public void setTotalSalary(Float totalSalary) {
		this.totalSalary = totalSalary;
	}

	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", comm=" + comm
				+ ", totalSalary=" + getTotalSalary() + ", empSal=" + empSal + "]";
	}

	


}
