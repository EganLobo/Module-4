package com.cg.appl.tests;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.servies.EmpServicceImpl;
import com.cg.appl.servies.EmpServices;

public class TestEmpServices {
	
	public static void main (String[] args)
	{
		try {
			EmpServices services = new EmpServicceImpl();
			//Emp emp = services.getEmpDetails(7499);
			//System.out.println(emp);
			
			/*for(Emp emp : services.getEmpList())
			{
				System.out.println(emp);
			}*/
			
			/*Emp emp = new Emp();
			emp.setEmpNo(9);
			emp.setEmpNm("Egan Lobo");
			emp.setEmpSal(75000);
			
			services.admitNewEmp(emp);
			System.out.println(services.getEmpDetails(9));
			*/
			
			/*services.updateName(9, "Icardi");
			System.out.println(services.getEmpDetails(9));*/
			
			/*Emp emp = new Emp();				//transient object
			emp.setEmpNo(9);
			emp.setEmpNm("Buffon");
			emp.setEmpSal(68000);
			
			services.updateEmp(emp);
			*/
			
			services.deleteEmp(1111);
			System.out.println(services.getEmpDetails(9));
			
			
			
		} catch (HrException e) {
			
			e.printStackTrace();
		}
	}
}
