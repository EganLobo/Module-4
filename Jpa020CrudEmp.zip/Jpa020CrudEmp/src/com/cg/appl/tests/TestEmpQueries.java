package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.servies.EmpServicceImpl;
import com.cg.appl.servies.EmpServices;

public class TestEmpQueries {

	public static void main(String[] args){
		
		try {
			EmpServices services = new EmpServicceImpl();

			//List<Emp> empList = services.getEmpsOnSal(1000, 5000);
			/*for(Emp emp : services.getEmpsOnSal(1000, 3000))
			{
				System.out.println(emp);
			}*/
			
			for(Emp emp: services.getEmpList())
			{
				System.out.println(emp);
			}
			
			/*Emp emp = new Emp();
			emp.setEmpNm("Maguire");
			emp.setEmpSal(85000);
			emp = services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			/*for(Emp emp: services.getEmpsForComm())
			{
				System.out.println(emp);
			}*/
			
			
		} catch (HrException e) {
			
			e.printStackTrace();
		}
	}

}
