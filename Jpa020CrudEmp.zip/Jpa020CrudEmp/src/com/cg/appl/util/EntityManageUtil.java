package com.cg.appl.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.appl.exceptions.HrException;

public class EntityManageUtil {
	private EntityManagerFactory factory;

	public EntityManageUtil() throws HrException {
		try {
			factory = Persistence.createEntityManagerFactory("JPA-PU");
		} catch (Exception e) {
			
			throw new HrException("Creation failed: Persistent Unit" , e);
		}

	}

	public EntityManager getManager() {

		return factory.createEntityManager();
	}
	
	public void closeFactory(){
		
		if(factory != null){
			factory.close();
				
		}
		
	}

	@Override
	protected void finalize() throws Throwable {
		closeFactory();
		super.finalize();
	}

}
