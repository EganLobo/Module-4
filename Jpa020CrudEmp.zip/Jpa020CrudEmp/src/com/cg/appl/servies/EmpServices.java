package com.cg.appl.servies;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public interface EmpServices {
	
	public Emp getEmpDetails(int empno) throws HrException;
	List<Emp> getEmpList() throws HrException;
	Emp admitNewEmp(Emp emp) throws HrException;
	public boolean updateName(int empNo, String newName) throws HrException;
	boolean updateEmp(Emp emp) throws HrException;
	boolean deleteEmp(int empno) throws HrException;
	List<Emp> getEmpsOnSal(float from, float to) throws HrException;
	List<Emp> getEmpsForComm() throws HrException;
}
