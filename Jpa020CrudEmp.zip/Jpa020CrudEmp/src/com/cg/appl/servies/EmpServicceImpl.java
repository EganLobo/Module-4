package com.cg.appl.servies;

import java.util.List;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.daos.EmpDaoImpl;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public class EmpServicceImpl implements EmpServices {

	private EmpDao dao;
	
	public EmpServicceImpl() throws HrException {
		dao = new EmpDaoImpl();
	}
	
	@Override
	public Emp getEmpDetails(int empno) throws HrException {
		
		return dao.getEmpDetailsSafe(empno);
	}

	@Override
	public List<Emp> getEmpList() throws HrException {
		
		return dao.getEmpList();
	}

	@Override
	public Emp admitNewEmp(Emp emp) throws HrException {
		
		return dao.admitNewEmp(emp);
	}

	@Override
	public boolean updateName(int empNo, String newName) throws HrException {
		
		return dao.updateName(empNo, newName);
	}

	@Override
	public boolean updateEmp(Emp emp) throws HrException {
		
		return dao.updateEmp(emp);
	}

	@Override
	public boolean deleteEmp(int empno) throws HrException {
		
		return dao.deleteEmp(empno);
	}

	@Override
	public List<Emp> getEmpsOnSal(float from, float to) throws HrException {
		
		return dao.getEmpsOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpsForComm() throws HrException {
		// TODO Auto-generated method stub
		return dao.getEmpsForComm();
	}

}
