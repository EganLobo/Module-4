/****************************************************************
*File 				:Emp.java
*Author 			:Egan Lobo
*Description 		:Entity class
*Last date modified : 31/3/2017

*****************************************************************/



package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "employee")
@Table(name = "EMPLOYEE")
@NamedQueries({ @NamedQuery(name = "qryAllEmps" , query = "select e from employee e")
	
})

@SequenceGenerator(name = "emp_generate", sequenceName = "hibernate_sequence" , allocationSize=1, initialValue=1001)

public class Emp implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int empNo;
	private String empNm;
	private String gender;
	private String designation;
	private String email;
	private String mobileno;
	
	
	@Id
	@Column(name="employee_code")
	@GeneratedValue(generator="emp_generate", strategy = GenerationType.SEQUENCE)
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	@NotEmpty(message="Name is required")
	@Column(name="EMPLOYEE_NAME")
	public String getEmpNm() {
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	@NotEmpty(message="Please select a gender")
	@Column(name="EMPLOYEE_GENDER")
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@NotEmpty(message="Please select a designation")
	@Column(name="DESIGNATION_NAME")
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	@NotEmpty(message="Email is mandatory")
	@Email(message="Please enter valid Email ID")
	@Column(name="EMPLOYEE_EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Size(min=10, max=10, message="Phone number should be of 10 digits")
	@Pattern(regexp = "^[1-9]+$", message="Phone number will aceept only 10 digits")
	@Column(name="EMPLOYEE_phone")
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", gender="
				+ gender + ", designation=" + designation + ", email=" + email
				+ ", mobileno=" + mobileno + "]";
	}
	
	
	
}


