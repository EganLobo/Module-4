/****************************************************************
*File 				:EmpDaoImpl
*Author 			:Egan Lobo
*Last date modified : 31/3/2017

*Description 		: Dao Implementation
*****************************************************************/

package com.cg.appl.daos;


import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import org.springframework.stereotype.Repository;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;


@Repository("empDao")
public class EmpDaoImpl implements EmpDao {
	@PersistenceContext
	private EntityManager manager;


	@Override
	public List<Emp> getAllEmp() throws EmpException {
	
		Query qry= manager.createNamedQuery("qryAllEmps", Emp.class);
		return qry.getResultList();
		
	}

	
	
	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException, RollbackException {
			
			manager.persist(emp); //inserting
			return emp;
	}

	
}
