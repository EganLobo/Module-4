/****************************************************************
*File 				:EmpCrudController
*Author 			:Egan Lobo
*Last date modified : 31/3/2017

*Description 		: Controller
*****************************************************************/

package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.BindingResultUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;

//http://localhost:8085/Spring120MVC_Login/login.jsp
@Controller
public class EmpCrudController {
	private EmpService services;
	private List<String> designationList;
	
	
	@Resource(name="empService")
	public void setTraineeServices(EmpService services)
		{
			this.services = services;
		}
	
	@PostConstruct
	public void intialize(){
		
		designationList= new ArrayList<>();
		designationList.add("Software Engineer");
		designationList.add("Senior Software Engineer");
		designationList.add("Team Lead");
		designationList.add("Manager");
		
	}
	
	
		//Give login.jsp
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	

	@RequestMapping("/listAllEmps.do")
	public ModelAndView listAllTrainees(){
		
		ModelAndView model= null;
		try {
			List<Emp> emp = services.getAllEmp();
			model = new ModelAndView("allEmpDetails");
			model.addObject("allEmpDetails", emp);
		} catch (EmpException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	@RequestMapping("/insertEmpDetails.do")
	public ModelAndView insertEmpDetails(){
		
		ModelAndView model = new ModelAndView("insertEmp");
		Emp e = new Emp();
		model.addObject("emp", e);
		model.addObject("designations", designationList);
		return model;
	}
	
	
	@RequestMapping("/submitInsertForm.do")
	public ModelAndView submitinsertForm(@ModelAttribute("emp") @Valid Emp emp, BindingResult result){
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors())
		{	
			model.setViewName("insertEmp");
			model.addObject("designations", designationList);
			return model;
		
		}
		
		try {
			Emp empResponse = services.insertNewEmp(emp);
			model.setViewName("successInsert");
			model.addObject("emp", empResponse);
			
		} catch (EmpException e) {
			
			model= new ModelAndView("error");
			model.addObject("errmsg", "Record insertion failed: " + e.getMessage());
		}
		return model;
	}
	
	
}
