/****************************************************************
*File 				:EmpServiceImpl
*Author 			:Egan Lobo
*Last date modified : 31/3/2017

*Description 		: Service Implementation
*****************************************************************/

package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.RollbackException;



import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Service("empService")
@Transactional
public class EmpServiceImpl implements EmpService {
	private EmpDao dao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmpDao dao){
		this.dao=dao;
	}
	
	@Override
	public List<Emp> getAllEmp() throws EmpException {
		
		return dao.getAllEmp();
	}

	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException, RollbackException {
		
		return dao.insertNewEmp(emp);
	}

}
