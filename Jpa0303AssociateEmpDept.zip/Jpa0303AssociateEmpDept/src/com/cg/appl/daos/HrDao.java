package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;

public interface HrDao {
	
	Emp getEmpDetailsSafe(int empno) throws HrException;
	List<Emp> getEmpList() throws HrException;

	List<Emp> getEmpsOnSal(float from, float to) throws HrException;
	List<Emp> getEmpsForComm() throws HrException;
	
	Dept getDeptDetails(int deptId) throws HrException;
}
