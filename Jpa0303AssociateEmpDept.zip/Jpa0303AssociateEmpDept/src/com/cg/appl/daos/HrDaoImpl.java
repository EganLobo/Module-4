package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.util.EntityManageUtil;

public class HrDaoImpl implements HrDao {

	private EntityManageUtil util;
	private EntityManager manager;

	public HrDaoImpl() throws HrException {
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	
	private Emp getEmpDetails(int empno) throws HrException {
		Emp emp = manager.find(Emp.class, empno);
		if (emp == null) {
			throw new HrException("Wrong emp number");
		}
		return emp;
	}
	
	@Override
	public Emp getEmpDetailsSafe(int empno) throws HrException {
		Emp emp = manager.find(Emp.class, empno);
		if (emp == null) {
			throw new HrException("Wrong emp number");
		}
		manager.detach(emp);
		return emp;
	}

	@Override
	public List<Emp> getEmpList() throws HrException {
		
		try {
			//Query qry = manager.createQuery("select e from employee e");
			Query qry = manager.createNamedQuery("qryAllEmps", Emp.class);
			List<Emp> empList = qry.getResultList();
			return empList;
		} catch (Exception e) {
			throw new HrException("Improper query fabrication", e);
		}

	}

	
	@Override
	public List<Emp> getEmpsOnSal(float from, float to) throws HrException {
		//String qryStr = "select e from employee e where empSal between :from and :to";
		//TypedQuery<Emp> qry = manager.createQuery(qryStr, Emp.class);
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsOnSal", Emp.class);
		qry.setParameter("from", from);
		qry.setParameter("to", to);
		return qry.getResultList();
	}
	
	@Override
	public List<Emp> getEmpsForComm() throws HrException {
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsComm", Emp.class);
		return qry.getResultList();
	}

	
	@Override
	public Dept getDeptDetails(int deptId) throws HrException {
		Dept dept = manager.find(Dept.class, deptId);
		if (dept== null)
		{
			throw new HrException("Wrong Department.");
		}
		return dept;
	}

	
	
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}


	

	


	

	

	
	

}
