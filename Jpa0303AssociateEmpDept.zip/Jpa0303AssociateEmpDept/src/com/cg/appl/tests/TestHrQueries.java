package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.entities.Dept;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.servies.HrServicceImpl;
import com.cg.appl.servies.HrServices;

public class TestHrQueries {

	public static void main(String[] args){
		
		try {
			HrServices services = new HrServicceImpl();
			
			//services.getEmpDetails(7499);
			Emp emp = services.getEmpDetails(7499);
			//Dept dept = services.getDeptDetails(emp.getDeptId());
			System.out.println(emp);
			//System.out.println(dept);
			System.out.println(emp.getDept().getDeptNm());
			System.out.println("--------------------------------");
			Dept dept = services.getDeptDetails(30);
			for(Emp emp1: dept.getEmps()){
				System.out.println(emp1);
			}
			
		} catch (HrException e) {
			
			e.printStackTrace();
		}
	}

}
