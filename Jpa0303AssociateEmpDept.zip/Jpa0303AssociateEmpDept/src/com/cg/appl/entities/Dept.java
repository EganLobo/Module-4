package com.cg.appl.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name ="dept")
@Table(name = "DEPT")

public class Dept {

	private int deptId;
	private String deptNm;
	private List<Emp> emps;
	
	@OneToMany(mappedBy = "dept")
	
	public List<Emp> getEmps() {
	return emps;
	}

	public void setEmps(List<Emp> emps) {
		this.emps = emps;
	}

	@Id
	@Column(name = "DEPTNO")
	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	@Column(name = "DNAME")
	public String getDeptNm() {
		return deptNm;
	}


	public void setDeptNm(String deptNm) {
		this.deptNm = deptNm;
	}

	@Override
	public String toString() {
		return "Dept [deptId=" + deptId + ", deptNm=" + deptNm + ", emps=" + emps + "]";
	}

	
	
}
